var webpack  = require('webpack');
//使用插件
var uglify = new webpack.optimize.UglifyJsPlugin({mangle:false,sourcemap:false});

module.exports = {
	entry: './main.js',
	output: {
      path: './dist', //打包输出的目录  
      filename: 'bundle.js' // 打包输出的文件 
  },
  module:{
    loaders:[{
        test:/\.css$/,
        loader: 'style-loader!css-loader'
    },{
        test:/\.png|jpg$/,
        loader:'url-loader?limit=1024'
    },{
        test:/\.less$/,
        loader: 'style-loader!css-loader!less-loader'
    }]
  },
  resolve:{
     extensions: ['','.js','.less','.css'] //配置后缀省略
  },
  plugins:[],
  devServer:{
      port:9000,
      contentBase:'./',
      historyApiFallback:true, //启动对H5 history api 的支持
      stats:"error-only"
  }
}