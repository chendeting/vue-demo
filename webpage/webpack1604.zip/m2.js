module.exports={
	setColor:function(dom,color){
       dom.style.color = color
	}
}