var color  = "red"

module.exports = color;