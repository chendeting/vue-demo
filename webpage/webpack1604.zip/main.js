
var setColor = require('./m2');
var color = require('./m1');
//加载一段css过来

require('./common.css');

require('./test');

var img = require('./wechat.png')


var IMG = new Image();

IMG.src =   img;

IMG.onload=function(){
	document.querySelector('.box').appendChild(IMG);
}

var dom = document.querySelector('.box');

setColor.setColor(dom,color);